package edu.CSE360.rec01.group04;

//import java.util.Observer;
import java.util.Observable;
import javax.swing.*;
import java.awt.*;
import java.util.LinkedList;
import java.util.List;

abstract class Subject  {
	
	private List<Observer> _observers = new LinkedList<Observer>();
	
	public void Attach(Observer obs) {
		_observers.add(obs);
	}
	
	public void Detach(Observer obs) {
		_observers.remove(obs);
	}
	
	public void Notify() {
		
		for (int i = 0; i < _observers.size(); i++) {
			Observer o = _observers.get(i);
			o.update();
		}
	}
	
}
