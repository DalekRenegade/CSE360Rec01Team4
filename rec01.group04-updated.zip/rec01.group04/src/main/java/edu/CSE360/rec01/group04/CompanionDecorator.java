package edu.CSE360.rec01.group04;
import javax.swing.JComponent;
public class CompanionDecorator implements Companion {
	
	protected Companion c;
	
	public void add(Companion c) {
		this.c = c;
	}
	
	
	public void doSomething(JComponent panel) {
		this.c.doSomething(panel);
	}

}
