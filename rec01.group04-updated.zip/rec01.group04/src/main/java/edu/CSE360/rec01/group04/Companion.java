package edu.CSE360.rec01.group04;
import javax.swing.JComponent;

public interface Companion {
	
	public void doSomething(JComponent panel);

}
