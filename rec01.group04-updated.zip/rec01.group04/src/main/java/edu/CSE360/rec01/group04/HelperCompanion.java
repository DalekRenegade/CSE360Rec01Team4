package edu.CSE360.rec01.group04;
import javax.swing.JComponent;
public class HelperCompanion extends CompanionDecorator {
	
	@Override
	public void doSomething(JComponent panel) {
		super.doSomething(panel);
		
	}

}
