package edu.CSE360.rec01.group04;

public abstract class Observer {
	
	public abstract void update();

}
