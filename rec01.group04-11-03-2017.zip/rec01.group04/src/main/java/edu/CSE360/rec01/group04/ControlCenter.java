package edu.CSE360.rec01.group04;


public class ControlCenter {
	
	private static ControlCenter _instance;
	
	private int[][] correctAnswers = new int[6][2];
	private int[][] wrongAnswers = new int[6][2];
	private int[][] timeSpent = new int[6][2];
	private int total[] = new int[4];
	private String status = "";
	
	
	protected ControlCenter() {}
	
	public static ControlCenter getInstance() {
		if (_instance == null) {
			_instance = new ControlCenter();
		} 
		
		return _instance;
	}
	
	public void setCorrect(int i, int j) {
		correctAnswers[i][j]++;
		total[i]++;
	}
	
	public void setWrong(int i, int j) {
		wrongAnswers[i][j]++;
		total[i]++;
	}
	
	public void setTime(int i, int j, int s) {
		timeSpent[i][j] += s;
		
	}
	
	public int[][] getStatus() {
		int numCorrect[] = new int[4];
		int numWrong[] = new int[4];
		int avgTimeSpent[] = new int[4];
		String status = "";
		
		int[][] retVal = new int[3][4];
		
		//set all values to zero
		for (int i = 0; i < 4; i++) {
			numCorrect[i] = 0;
			numWrong[i] = 0;
			avgTimeSpent[i] = 0;
		}
		
		//get total number of correct
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 2; j++) {
				numCorrect[i] += correctAnswers[i][j];
				numWrong[i] += wrongAnswers[i][j];
				avgTimeSpent[i] += timeSpent[i][j];
			}
			//calculate avgTimeSpent but do not divide by 0
			if (total[i] != 0)
				avgTimeSpent[i] = avgTimeSpent[i]/total[i];
			
			//build the array to return
			retVal[0][i] = numCorrect[i];
			retVal[1][i] = numWrong[i];
			retVal[2][i] = avgTimeSpent[i];
			
		}
		
		return retVal;
	}

}
