package edu.CSE360.rec01.group04;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;


public class Main extends JFrame implements ActionListener {

	CompanionPanel panel = new CompanionPanel();
	JButton b1 = new JButton("standard");
	JButton b2 = new JButton("help");
	JButton b3 = new JButton("affect"); 
	JButton b4 = new JButton("helper+affect");

	public Main() {
		setLayout(new BorderLayout(3,2));
		add (panel, BorderLayout.CENTER);
		JPanel control = new JPanel(new GridLayout(1,4));
		control.add(b1); 
		b1.addActionListener(this);
		control.add(b2); 
		b2.addActionListener(this);
		control.add(b3); 
		b3.addActionListener(this);
		control.add(b4); 
		b4.addActionListener(this);
		add(control, BorderLayout.SOUTH);

	}
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource()==b1) {
			BasicCompanion basic = new BasicCompanion(); 
			panel.setCompanion(basic); 
			panel.showYourself();
		} else if (e.getSource()==b2) {
			BasicCompanion basic = new BasicCompanion(); 
			HelperCompanion helper = new HelperCompanion(); 
			helper.add(basic);
			panel.setCompanion(helper); 
			panel.showYourself();
		} else if (e.getSource()==b3) {
			BasicCompanion basic = new BasicCompanion(); 
			AffectiveCompanion h = new AffectiveCompanion(); 
			h.add(basic);
			panel.setCompanion(h); 
			panel.showYourself();
		} else if (e.getSource()==b4) {
			HelperCompanion helper2 = new HelperCompanion(); 
			AffectiveCompanion affective = new AffectiveCompanion(); 
			BasicCompanion basic2 = new BasicCompanion(); 
			helper2.add(affective);
			affective.add(basic2); 
			panel.setCompanion(helper2);
			panel.showYourself();
		}
	}
	public static void main(String[] args) {
		JFrame main = new Main();
		main.setSize(500,500);
		main.setVisible(true); main.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
