package edu.CSE360.rec01.group04;
import javax.swing.JLayeredPane;
import java.awt.GridLayout;

public class CompanionPanel extends JLayeredPane {
	
	public Companion brain;
	
	public void setCompanion(Companion x) {
		brain = x;
	}
	
	public void showYourself() {
		removeAll();
		setLayout(new GridLayout(1,1));
		brain.doSomething(this);
		revalidate();
	}
	
}
