package edu.CSE360.rec01.group04;


public class ControlCenter {
	
	private static ControlCenter _instance;
	
	private int[][] correctAnswers = new int[4][2];
	private int[][] wrongAnswers = new int[4][2];
	private double[][] timeSpent = new double[4][2];
	private String status = "";
	
	protected ControlCenter() {}
	
	public static ControlCenter getInstance() {
		if (_instance == null) {
			_instance = new ControlCenter();
		} 
		
		return _instance;
	}
	
	public void setCorrect(int i, int j) {
		correctAnswers[i][j]++;
	}
	
	public void setWrong(int i, int j) {
		wrongAnswers[i][j]++;
	}
	
	public double calcTime(int i, int j, int total, double s) {
		timeSpent[i][j] += s;
		
		return (double) timeSpent[i][j]/total;
	}
	
	public String getStatus() {
		int good = 0;
		int bad = 0;
		int worried = 0;
		
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 2; j++) {
				if (correctAnswers[i][j] > wrongAnswers[i][j]*2 && timeSpent[i][j] <= 90.0) {
					good++;
				} else if (correctAnswers[i][j] > wrongAnswers[i][j]*2 && timeSpent[i][j] > 90.0) {
					worried++;
				} else {
					bad++;
				}
			}
			
		}
		
		if (good > (bad + worried)) {
			status = "Excellent";
		} else if (good > bad) {
			status = "Good";
		} else if (good > worried) {
			status = "Bad";
		} else if (good == 0 && bad == 0 && worried == 0) {
			
			status = "unset";
		} else {
			status = "Help!";
		}
		
		return status;
	}

}
