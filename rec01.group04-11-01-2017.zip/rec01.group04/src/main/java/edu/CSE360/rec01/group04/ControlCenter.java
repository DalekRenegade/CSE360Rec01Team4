package edu.CSE360.rec01.group04;


public class ControlCenter {
	
	private static ControlCenter _instance;
	
	private int[][] correctAnswers = new int[6][2];
	private int[][] wrongAnswers = new int[6][2];
	private int[][] timeSpent = new int[6][2];
	private int total = 0;
	private String status = "";
	
	protected ControlCenter() {}
	
	public static ControlCenter getInstance() {
		if (_instance == null) {
			_instance = new ControlCenter();
		} 
		
		return _instance;
	}
	
	public void setCorrect(int i, int j) {
		correctAnswers[i][j]++;
		total++;
	}
	
	public void setWrong(int i, int j) {
		wrongAnswers[i][j]++;
		total++;
	}
	
	public void setTime(int i, int j, int s) {
		timeSpent[i][j] += s;
		
	}
	
	public String getStatus() {
		int numCorrect = 0;
		int numWrong = 0;
		int avgTimeSpent = 0;
		String status = "";
		
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 2; j++) {
				numCorrect += correctAnswers[i][j];
				numWrong += wrongAnswers[i][j];
				avgTimeSpent += timeSpent[i][j];
			}
			
		}
		if (total != 0)
			avgTimeSpent = avgTimeSpent/total;
		System.out.println("correct: " + numCorrect);
		System.out.println("Wrong: " + numWrong);
		System.out.println("Total: " + total);
		System.out.println("Avg Time: " + avgTimeSpent);
		
		if (numCorrect == 0 && numWrong == 0) {
			status = "unset";
		} else if (numCorrect > numWrong*1.5 && avgTimeSpent < 90) {
			status = "Excellent";
		} else if (numCorrect > numWrong*1.1 && avgTimeSpent < 90) {
			status = "Good";
		} else if (numCorrect >= numWrong && avgTimeSpent < 90) {
			status = "Bad";
		} else if (numCorrect > numWrong*3 && avgTimeSpent > 90) {
			status = "Excellent";
		} else if (numCorrect >= numWrong*2 && avgTimeSpent > 90) {
			status = "Good";
		} else if (numCorrect >= numWrong && avgTimeSpent > 90) {
			status = "Bad";
		} else {
			status = "Help!";
		}
		
		return status;
	}

}
